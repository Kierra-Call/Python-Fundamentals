print("Hello World")
first_name = "Kierra"
print("Hello ",first_name)
print("Hello " + first_name)
num = 7
print("Hello ",num)
# print("Hello " + num)
food_one = "Mac and cheese"
food_two = "Tacos"
print("I love to eat {} and {}".format(food_one, food_two))
print(f"I love to eat {food_one} and {food_two}")
